create definer = root@localhost view view_kategorie_vegetarisch as
select `emensawerbeseite`.`gericht`.`name` AS `Gericht`, `emensawerbeseite`.`kategorie`.`name` AS `Kategorie`
from ((`emensawerbeseite`.`gericht` left join `emensawerbeseite`.`gericht_hat_kategorie` `ghk` on (`emensawerbeseite`.`gericht`.`id` = `ghk`.`gericht_id`))
         left join `emensawerbeseite`.`kategorie` on (`ghk`.`kategorie_id` = `emensawerbeseite`.`kategorie`.`id`))
where `emensawerbeseite`.`gericht`.`vegetarisch` = 1
union
select NULL AS `NULL`, `emensawerbeseite`.`kategorie`.`name` AS `name`
from `emensawerbeseite`.`kategorie`;

