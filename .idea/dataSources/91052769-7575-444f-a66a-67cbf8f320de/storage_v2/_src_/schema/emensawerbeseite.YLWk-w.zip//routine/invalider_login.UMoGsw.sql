create
    definer = root@localhost procedure invalider_login(IN input_email varchar(100))
BEGIN
    UPDATE benutzer SET anzahlfehler = anzahlfehler + 1 WHERE benutzer.email=input_email;
    UPDATE benutzer SET letzterfehler = CURRENT_TIMESTAMP WHERE benutzer.email=input_email;
END;

