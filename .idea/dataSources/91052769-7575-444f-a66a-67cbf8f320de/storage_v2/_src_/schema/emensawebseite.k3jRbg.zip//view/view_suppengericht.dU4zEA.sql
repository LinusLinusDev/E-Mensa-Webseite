create view view_suppengericht as
select `emensawebseite`.`gericht`.`id`           AS `id`,
       `emensawebseite`.`gericht`.`name`         AS `name`,
       `emensawebseite`.`gericht`.`beschreibung` AS `beschreibung`,
       `emensawebseite`.`gericht`.`erfasst_am`   AS `erfasst_am`,
       `emensawebseite`.`gericht`.`vegetarisch`  AS `vegetarisch`,
       `emensawebseite`.`gericht`.`vegan`        AS `vegan`,
       `emensawebseite`.`gericht`.`preis_intern` AS `preis_intern`,
       `emensawebseite`.`gericht`.`preis_extern` AS `preis_extern`,
       `emensawebseite`.`gericht`.`bildname`     AS `bildname`
from `emensawebseite`.`gericht`
where `emensawebseite`.`gericht`.`name` like '%suppe%';

