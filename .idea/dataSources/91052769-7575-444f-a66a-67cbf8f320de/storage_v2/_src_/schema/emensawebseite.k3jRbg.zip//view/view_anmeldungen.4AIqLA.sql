create view view_anmeldungen as
select `emensawebseite`.`benutzer`.`email`             AS `email`,
       `emensawebseite`.`benutzer`.`anzahlanmeldungen` AS `anzahlanmeldungen`
from `emensawebseite`.`benutzer`
order by `emensawebseite`.`benutzer`.`anzahlanmeldungen` desc;

