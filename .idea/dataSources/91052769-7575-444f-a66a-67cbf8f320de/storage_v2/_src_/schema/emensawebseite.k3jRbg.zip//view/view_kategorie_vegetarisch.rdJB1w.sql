create view view_kategorie_vegetarisch as
select `emensawebseite`.`gericht`.`name` AS `Gericht`, `emensawebseite`.`kategorie`.`name` AS `Kategorie`
from ((`emensawebseite`.`gericht` left join `emensawebseite`.`gericht_hat_kategorie` `ghk` on (`emensawebseite`.`gericht`.`id` = `ghk`.`gericht_id`))
         left join `emensawebseite`.`kategorie` on (`ghk`.`kategorie_id` = `emensawebseite`.`kategorie`.`id`))
where `emensawebseite`.`gericht`.`vegetarisch` = 1
union
select NULL AS `NULL`, `emensawebseite`.`kategorie`.`name` AS `name`
from `emensawebseite`.`kategorie`;

